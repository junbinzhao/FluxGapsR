library(testthat)
library(neuralnet)

test_check("neuralnet")