library(testthat)
library(Deriv)

test_check("Deriv")
